#!/bin/bash

SCRIPT_NAME="$(basename "$0")"
BASE_NAME="${SCRIPT_NAME%.sh}"
REPORT_FILE="report_${BASE_NAME}.log"
FIFO="/tmp/run/cuckoo.pid"

# Проверка имени скрипта, на соответствие
if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
	echo "я бригадир, сам не работаю"
	exit 1
fi

START_TIME=$(date +%s)

log_msg() {
	echo "$(date '+%F %T') [$$] $1" >> "$REPORT_FILE"
}

log_msg "Скрипт запущен"

# Отправляем запрос в cuckoo
echo "${BASE_NAME}[$$]: how much time do I have?" > "$FIFO" 

# Ждем ответ от cuckoo из его лога
while true; do 
	LAST_LINE=$(grep "${BASE_NAME}\[$$\]" cuckoo.log | tail -n 1)
	if [[ -n "$LAST_LINE" ]]; then
		N=$(echo "$LAST_LINE" | awk '{print $NF}')
		if [[ "$N" =~ ^[0-9]+$ ]]; then 
		   break
		fi
	fi
	sleep 1
done

sleep "$N"
END_TIME=$(date +%s)
WORK_TIME=$((END_TIME - START_TIME))

log_msg "Скрипт завершился, работал ${WORK_TIME} секунд."

