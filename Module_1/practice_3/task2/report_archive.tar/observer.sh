#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG_FILE="$SCRIPT_DIR/observer.conf"
LOG_FILE="$SCRIPT_DIR/observer.log"

log_msg() {
    echo "$(date '+%F %T') $1" >> "$LOG_FILE"
}

if [[ ! -f "$CONFIG_FILE" ]]; then
    echo "Файл $CONFIG_FILE не найден"
    exit 1
fi

while read -r script_name; do
    [[ -z "$script_name" || "$script_name" =~ ^# ]] && continue

    if ! pgrep -f "$script_name" > /dev/null; then
        nohup "$SCRIPT_DIR/$script_name" > /dev/null 2>&1 &
        log_msg "Перезапуск $script_name"
    fi
done < "$CONFIG_FILE"    

