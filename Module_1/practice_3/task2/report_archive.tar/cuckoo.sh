#!/bin/bash

FIFO="/tmp/run/cuckoo.pid"
LOGFILE="cuckoo.log"

mkdir -p /tmp/run

# Если канал уже существует, удалим его
[ -p "$FIFO" ] && rm -f "$FIFO"
mkfifo "$FIFO"

log_msg(){
        echo "$(date '+%F %T') $1" >> "$LOGFILE"
}

shutdown_handler(){
        log_msg "Shutdown!"
        rm -f "$FIFO"
        exit 0
}

# Дополнительно можно завершать, через SIGTERM SIGINT
trap shutdown_handler SIGTERM SIGINT

log_msg "Startup!"

while true; do
    if read -r line < "$FIFO"; then

        if [[ $line == *": how much time do I have?" ]]; then
            prefix="${line%: how much time do I have?}"
            NAME="${prefix%%\[*}"
            PID="${prefix#*\[}"
            PID="${PID%\]}"

            if [[ -n $NAME && $PID =~ ^[0-9]+$ ]]; then
                N=$((RANDOM % 9 + 2))
                log_msg "${NAME}[${PID}] ${N}"
            fi
        fi
    fi
done
